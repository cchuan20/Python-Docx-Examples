import docx
from docx.oxml.shared import OxmlElement,qn
from docx.shared import Pt,Cm,RGBColor
from random import randint
import random
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ROW_HEIGHT

myText = ['時間','參與者','舉行地點','討論事項']
side = ['w:bottom']
          
doc = docx.Document()
table = doc.add_table(rows=4,cols=3,style='Normal Table')

def table_cell_border(cell):
    tcB = cell._tc.tcPr
    tcBorders = OxmlElement('w:tcBorders')
    for bound in side:
        tblbound = OxmlElement(bound)
        tblbound.set(qn('w:val'),'single')
        tblbound.set(qn('w:color'),'0000FF')
        tblbound.set(qn('w:space'),'0')
        tblbound.set(qn('w:sz'),'6')
        tcBorders.append(tblbound)
        tcB.append(tcBorders)
    return None

for i in range(len(table.rows)):
    table.rows[i].height_rule = WD_ROW_HEIGHT.EXACTLY
    table.rows[i].height = Cm(1.2)
    for j in range(len(table.columns)):
        cell = table.cell(i,j)
        cell.vertical_alignment = WD_ALIGN_VERTICAL.BOTTOM
        para = cell.paragraphs[0]
        paragraph_format = para.paragraph_format
        paragraph_format.space_before = Pt(0)
        paragraph_format.space_after  = Pt(0)
        para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.LEFT
        if j == 2 :
            table_cell_border(cell)

def genRandom():
    a = str(randint(100,999))
    b = str(randint(100,999))
    c = str(randint(100,999))
    d = str('-')
    return str(d+a+b+c)

def fitText(run):
    tag = run._r.get_or_add_rPr()
    fitText = OxmlElement('w:fitText') 
    fitText.set(qn('w:val'),'4026')
    fitText.set(qn('w:id'),genRandom())
    tag.append(fitText)
    return None

for row in range(len(table.rows)):
    run = table.rows[row].cells[0].paragraphs[0].add_run()
    run.font.size = Pt(18)
    run.font.color.rgb = RGBColor(0xff,0x00,0x00)
    run.text = str(myText[row])
    fitText(run)
    run1 = table.rows[row].cells[1].paragraphs[0].add_run()
    run1.font.size = Pt(18)
    run1.font.color.rgb = RGBColor(0xff,0x00,0x00)
    run1.text = str(':')

doc.save('fitText_20240711_4.docx')


